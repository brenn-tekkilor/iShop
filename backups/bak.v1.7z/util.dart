import 'dart:math';

import 'package:flutter/material.dart';

class ConstKeys {
  static const deviceKey = 'device_size';
  static const roundAngelKey = 'round_angle_size';
  static const regularPolygonKey = 'regular_angle_size';
  static const circleKey = 'circle custom painter';
  static const circleTriangleKey = 'circle triangle painter';
  static const logoKey = 'logo_page_size';
}


class MeasuredValue {
  double value;
  UnitOfMeasureType unitOfMeasure;
}

class TimeRangeOfDay {
  TimeOfDay start;
  TimeOfDay end;
  bool is24Hours;
}

//#endregion

class CanvasDesigner {
  static final Map<String, CanvasDesigner> _keyValues = {};

  static void initDesignSize() {
    getInstance(key: ConstKeys.roundAngelKey).designSize = Size(500.0, 500.0);
    getInstance(key: ConstKeys.regularPolygonKey).designSize =
        Size(500.0, 500.0);
    getInstance(key: ConstKeys.logoKey).designSize = Size(580, 648.0);
    getInstance(key: ConstKeys.circleKey).designSize = Size(500.0, 500.0);
    getInstance(key: ConstKeys.circleTriangleKey).designSize =
        Size(500.0, 500.0);
  }

  //device pixel ratio.
  Size _designSize;

  //logic size in device
  Size _logicalSize;

  static CanvasDesigner getInstance({key = ConstKeys.deviceKey}) {
    if (_keyValues.containsKey(key)) {
      return _keyValues[key];
    } else {
      _keyValues[key] = CanvasDesigner();
      return _keyValues[key];
    }
  }

  set designSize(Size size) {
    _designSize = size;
  }

  double get width => _logicalSize.width;

  double get height => _logicalSize.height;

  set logicSize(Size size) => _logicalSize = size;

  double getAxisX(double designWidth) {
    return (designWidth * width) / _designSize.width;
  }

  // the y direction
  double getAxisY(double h) {
    return (h * height) / _designSize.height;
  }

  // diagonal direction value with design size s.
  double getAxisBoth(double s) {
    return s *
        sqrt((width * width + height * height) /
            (_designSize.width * _designSize.width +
                _designSize.height * _designSize.height));
  }
}
